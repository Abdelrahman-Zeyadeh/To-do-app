import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.Task

class TaskAdapter(private val tasks: List<Task>) :
    RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val taskText: TextView = itemView.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_1, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = tasks[position]
        holder.taskText.text = "${task.title} - ${task.priority}"

        // Set text color based on English priority
        when (task.priority.lowercase()) {
            "high" -> holder.taskText.setTextColor(Color.RED)
            "medium" -> holder.taskText.setTextColor(Color.parseColor("#FFA500")) // orange
            "low" -> holder.taskText.setTextColor(Color.GREEN)
            else -> holder.taskText.setTextColor(Color.BLACK)
        }
    }

    override fun getItemCount(): Int = tasks.size
}
